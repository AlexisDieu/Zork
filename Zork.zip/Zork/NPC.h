#ifndef __NPC__
#define __NPC__

#include "Creature.h"

using namespace std;

class NPC : public Creature
{

public:

	NPC();
	~NPC();

private:

};

#endif //__NPC__